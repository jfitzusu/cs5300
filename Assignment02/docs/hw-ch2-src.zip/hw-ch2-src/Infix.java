public class Infix {

    public static void main(String[] args) {
        String str = "+++12-835";
        if (args.length > 0) {
            str = args[0];
        }
        try {
            Infix parser = new Infix(str);
        } catch (Exception e) {
            System.out.println("error");
        }
    }

    public Infix(String terminals) {
    }
}
